/*
using UnityEngine;
using System.Collections;

public class SpinosaurusSpecialUtilty : MonoBehaviour
{
    [SerializeField] private GameObject Neck;
    [SerializeField] private GameObject Head;
        
    
    Animator HeadAnimator;

    private void Awake()
    {
        HeadAnimator = Head.GetComponent<Animator>();
    }
    
    
    
    
    private IEnumerator ExtendRetractNeck()
    {
        
    }
    
}
*/