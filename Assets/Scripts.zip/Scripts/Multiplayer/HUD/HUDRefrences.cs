using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class HUDRefrences : MonoBehaviour
{
    public Image SplashArtImage;
    public Slider HpBar;
    public Slider EnergyBar;
    public TMP_Text ScoreText;
}
