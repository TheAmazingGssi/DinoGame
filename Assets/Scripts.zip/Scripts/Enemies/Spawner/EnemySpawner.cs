using System.Collections;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    private const string Player = "Player";

    [HideInInspector] public GameObject EnemyPrefab;

    [HideInInspector] public float MinSpawnTime;
    [HideInInspector] public float MaxSpawnTime;

    [HideInInspector] public int EnemiesInWaveMultiplier = 2;
    private int EnemiesInWave;

    [SerializeField] Transform[] spawnPoints;

    private bool wasTriggered = false;

    private IEnumerator SpawnWave()
    {
        for (int i = 0; i < EnemiesInWave; i++)
        {
            Instantiate(EnemyPrefab, spawnPoints[Random.Range(0, spawnPoints.Length)].position, Quaternion.identity);
            yield return new WaitForSeconds(Random.Range(MinSpawnTime, MaxSpawnTime));
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag(Player))
        {
            if(!wasTriggered)
            {
                EnemiesInWave = PlayerEntity.PlayerList.Count * EnemiesInWaveMultiplier;
                GameManager.Instance.SetWaveSize(EnemiesInWave);
                StartCoroutine(SpawnWave());
                wasTriggered = true;
            }
        }
    }
}
